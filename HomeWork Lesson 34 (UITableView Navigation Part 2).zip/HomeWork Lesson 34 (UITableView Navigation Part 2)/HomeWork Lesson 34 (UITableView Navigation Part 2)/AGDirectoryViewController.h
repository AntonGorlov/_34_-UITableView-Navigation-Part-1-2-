//
//  AGDirectoryViewController.h
//  HomeWork Lesson 34 (UITableView Navigation Part 2)
//
//  Created by Anton Gorlov on 19.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGDirectoryViewController : UITableViewController


- (id) initWithFolderPath:(NSString*) path;

- (IBAction)actionCreateNewDirectory:(UIBarButtonItem *)sender;

@end
