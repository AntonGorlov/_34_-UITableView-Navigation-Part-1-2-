//
//  AGFolderCell.m
//  HomeWork Lesson 34 (UITableView Navigation Part 2)
//
//  Created by Anton Gorlov on 19.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGFolderCell.h"

@implementation AGFolderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
