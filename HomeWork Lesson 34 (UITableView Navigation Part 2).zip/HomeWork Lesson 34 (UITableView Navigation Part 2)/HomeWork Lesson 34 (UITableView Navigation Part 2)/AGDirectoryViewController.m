//
//  AGDirectoryViewController.m
//  HomeWork Lesson 34 (UITableView Navigation Part 2)
//
//  Created by Anton Gorlov on 19.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDirectoryViewController.h"
#import "AGFileCell.h"
#import "AGFolderCell.h"


typedef enum {
    
    AGTypeDirectoryFile,
    AGTypeDirectoryFolder

}AGTypeDirectory;

@interface AGDirectoryViewController ()

@property (strong,nonatomic) NSString* path;
@property (strong, nonatomic) NSArray* contents;
@property(assign, nonatomic)BOOL sortByType;
@property(assign, nonatomic)BOOL isHidden;

/*
Я рекомендую вам немного задержаться на этом уроке и снова попрактиковать таблицы. Также будет довольно таки неплохо если вы углубитесь в NSFileManager

Ученик.

1. Добавьте возможность создавать директории
2. Добавьте возможность удалять файлы и папки

Студент

3. Сортируйте файлы и папки, сверху должны быть папки, снизу файлы, сортировка по имени
4. Не показывайте скрытые файлы

Мастер

5. В detailedTextField каждой ячейки файла, выводите размер файла.

Супермен

6. Тем же способом выводите размер папки (размер папки придется считать рекурсивно :) )
*/
@end

@implementation AGDirectoryViewController


- (id) initWithFolderPath:(NSString *)path {
    
    self = [super initWithStyle:UITableViewStylePlain];
    if (self) {
        self.path = path;
    }

    return self;
}



- (void) setPath:(NSString *)path {

    _path = path;
    
    NSError* error = nil;
    
    self.contents = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.path
                                                                        error:&error];
    
    if (error) {
        NSLog(@"%@", [error localizedDescription]);
    }
    
    [self.tableView reloadData];
    
    self.navigationItem.title = [self.path lastPathComponent];

}

-(void)loadView{
    
    [super loadView];
    [self createToolbarWithHiddenTitle:@"Hide"];
    
    self.tableView.editing = NO;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    if (!self.path) {
        
        self.path = @"/Users/AntonGorlov/Documents/Антон/Антошкины ДокументЫ/IOS Developer/Functiontest/PropertiesTest2/HomeWork Lesson 34 (UItableView Navigation Part 2)/FileManager";
    }
    
    self.isHidden = NO;
    self.sortByType = NO;
}

- (void) viewWillAppear:(BOOL)animated {

    [super viewWillAppear:YES];
    
    if ([self.navigationController.viewControllers count] > 1) {
        UIBarButtonItem* item = [[UIBarButtonItem alloc] initWithTitle:@"Back to Root"
                                                                 style:UIBarButtonItemStylePlain
                                                                target:self
                                                                action:@selector(actionBackToRoot:)];
        
        self.navigationItem.rightBarButtonItem = item;
    }
}

- (BOOL) isDirectoryAtIndexPath:(NSIndexPath*) indexPath {

    NSString* fileName = [self.contents objectAtIndex:indexPath.row];
    
    NSString* filePath = [self.path stringByAppendingPathComponent:fileName];
    
    BOOL isDirectory = NO;
    
    [[NSFileManager defaultManager] fileExistsAtPath:filePath isDirectory:&isDirectory];
    
    return isDirectory;
}

#pragma mark- Actions 


- (IBAction)actionCreateNewDirectory:(UIBarButtonItem *)sender {
    
    UIAlertController* alertView = [UIAlertController alertControllerWithTitle:@"Choose type of directory"
                                                                       message:nil
                                                                preferredStyle:UIAlertControllerStyleAlert];
  

    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"Cancel"
                                                            style:UIAlertActionStyleCancel handler:nil];
    
    
    UIAlertAction* createFolderAction = [UIAlertAction actionWithTitle:@"New folder"
                                                           style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                                                               [self createNewFolderWithTypeDirectory:AGTypeDirectoryFolder];
                                                           }];
    
    UIAlertAction* createFileAction = [UIAlertAction actionWithTitle:@"New file"
                                                                 style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                                                                     [self createNewFolderWithTypeDirectory:AGTypeDirectoryFile];
                                                                 }];
    
    [alertView addAction:createFolderAction];
    [alertView addAction:createFileAction];
    [alertView addAction:cancelAction];
    
    
    [self presentViewController:alertView
                       animated:YES
                     completion:nil];
}

- (void) createNewFolderWithTypeDirectory:(AGTypeDirectory) directory {
    
    NSString* nameFile = nil;
    
    if (directory == AGTypeDirectoryFile) {
        
        nameFile = @"new file";
        
    }else {
        
        nameFile = @"new folder";
        
}
    
    int indexNewFolder = [self countOfdirectoryWithString:nameFile];
    
    NSString* newFolder = [NSString stringWithFormat:@"%@ %d",nameFile, indexNewFolder + 1];
    NSString* newPath = [self.path stringByAppendingPathComponent:newFolder];
    
    NSMutableArray* tempArray = nil;
    NSError* error = nil;
    
    if (directory == AGTypeDirectoryFolder) {
        
        if (![[NSFileManager defaultManager] fileExistsAtPath:newPath]) {
            
            [[NSFileManager defaultManager]createDirectoryAtPath:newPath
                                     withIntermediateDirectories:NO
                                                      attributes:nil
                                                           error:&error];
            
        }
            
        } else {
            
            if (![[NSFileManager defaultManager]fileExistsAtPath:newPath]) {
                
                [[NSFileManager defaultManager] createFileAtPath:newPath
                                                        contents:nil
                                                      attributes:nil];
                
            }
            
        }
        
        if ([self.contents count] > 0) {
            
            tempArray = [NSMutableArray arrayWithArray:self.contents];
            
        }else{
            
            tempArray = [NSMutableArray array];
        }
        
        [tempArray insertObject:newFolder atIndex:0];
        self.contents = tempArray;
        
        [self.tableView beginUpdates];
        
        NSIndexPath* indexPath =[NSIndexPath indexPathForItem:0 inSection:0];
        
        [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationRight];
        
        [self.tableView endUpdates];
        
    
}

- (void) actionBackToRoot: (UIBarButtonItem*) sender {

    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (NSString*) fileSizeFromValue:(unsigned long long) size {

    static NSString* units [] = {@"B",@"KB",@"MB",@"GB",@"TB"};
    
    static int unitsCount = 5;
    
    int index = 0;
    
    double fileSize = (double) size;
    
    while (fileSize > 1024 && index < unitsCount) {
        
        fileSize /= 1024;
        
        index++;
    }

    return [NSString stringWithFormat:@"%.2f %@", fileSize, units[index]];
}

#pragma mark - Toolbar

-(int)countOfdirectoryWithString:(NSString*)string{ // нумерация новых папок
    
    NSArray* array = [self.contents filteredArrayUsingPredicate: [NSPredicate predicateWithFormat: @"SELF beginswith %@", string]];
    
    int newIndex = 0;
    int indexNewFolder = 0;
    
    for (int i = 0; i < [array count]; i++) {
        
        NSString* myString = [[array objectAtIndex:i] substringFromIndex:[[array objectAtIndex:i]length]-2];
        newIndex = [myString intValue];
        
        if (newIndex > indexNewFolder) {
            indexNewFolder = newIndex;
        }
    }
    
    return indexNewFolder;
}


-(void)createToolbarWithHiddenTitle:(NSString*)title{
    
    [self.navigationController setToolbarHidden:NO];
    
    UIBarButtonItem *editButton = [[ UIBarButtonItem alloc ] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit
                                                                                  target:self
                                                                                  action:@selector(editTable:)];
    
    UIBarButtonItem *hideButton = [[UIBarButtonItem alloc]initWithTitle:title
                                                                  style:UIBarButtonItemStylePlain
                                                                 target:self
                                                                 action:@selector(hideSystemFiles:)];
    
    UIBarButtonItem *sortType = [[UIBarButtonItem alloc]initWithTitle:@"SortByType"
                                                                style:UIBarButtonItemStylePlain
                                                               target:self
                                                               action:@selector(sortByType:)];
    
    self.toolbarItems = [ NSArray arrayWithObjects: editButton, hideButton, sortType, nil];
}


-(void)sortByType:(UIBarButtonItem*)barButton{
    
    self.sortByType = !self.sortByType;
    
    NSMutableArray* tempArray = [NSMutableArray array];
    
    for (NSString* string in self.contents) {
        
        NSInteger firstIndex = 0;
        NSInteger lastIndex = [tempArray count];
        
        NSString* pathName = [self.path stringByAppendingPathComponent:string];
        
        BOOL isDirectory = NO;
        [[NSFileManager defaultManager]fileExistsAtPath:pathName isDirectory:&isDirectory];
        
        
        if (self.sortByType) {
            
            isDirectory = !isDirectory;
        }
        if ([tempArray count] == 0) {
            
            [tempArray addObject:string];
            
        }else if (isDirectory) {
            
            [tempArray insertObject:string atIndex:firstIndex];
            
        }else{
            
            [tempArray insertObject:string atIndex:lastIndex];
        }
    }
    
    self.contents = tempArray;
    [self.tableView reloadData];
}


-(void)hideSystemFiles:(UIBarButtonItem*)barButton{
    
    self.isHidden = !self.isHidden;
    
    if (self.isHidden) {
        
        NSArray* array = [self.contents filteredArrayUsingPredicate: [NSPredicate predicateWithFormat: @"SELF beginswith %@", @"."]];
        
        for (NSString* string in array) {
            
            if ([array count] > 0) {
                NSMutableArray* tempArray = [NSMutableArray arrayWithArray:self.contents];
                [tempArray removeObject:string];
                
                self.contents = tempArray;
                [self createToolbarWithHiddenTitle:@"Unhide"];
            }
            
        }
        
    }else{
        
        NSArray* newArray = [[NSFileManager defaultManager]contentsOfDirectoryAtPath:self.path error:nil];
        NSMutableArray* tempArray = [NSMutableArray arrayWithArray:newArray];
        for (NSString* string in self.contents) {
            
            if ([self.contents filteredArrayUsingPredicate: [NSPredicate predicateWithFormat: @"SELF beginswith %@", string]]) {
                [tempArray removeObject:string];
            }
        }
        
        if (tempArray) {
            
            [tempArray addObjectsFromArray:self.contents];
        }
        
        self.contents = tempArray;
        
        [self createToolbarWithHiddenTitle:@"Hide"];
        
    }
    
    [self.tableView reloadData];
    
    
}

-(void)editTable:(UIBarButtonItem*)barButton{
    
    BOOL isEditing = self.tableView.editing;
    [self.tableView setEditing:!isEditing animated:YES];
    
    if (self.tableView.editing) {
        
        UIBarButtonItem *editButton = [[ UIBarButtonItem alloc ] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                                                                                      target:self
                                                                                      action:@selector(editTable:)];
        self.toolbarItems = [ NSArray arrayWithObject: editButton];
        
    }else{
        
        [self createToolbarWithHiddenTitle:@"Hide"];
    }
}


- (unsigned long long int)folderSize:(NSString *)folderPath {
    
    unsigned long long int result = 0;
    
    NSArray *array = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:folderPath error:nil];
    
    for (NSString *fileSystemItem in array) {
        
        BOOL directory = NO;
        
        [[NSFileManager defaultManager] fileExistsAtPath:[folderPath stringByAppendingPathComponent:fileSystemItem] isDirectory:&directory];
        
        if (!directory) {
            
            result += [[[[NSFileManager defaultManager] attributesOfItemAtPath:[folderPath stringByAppendingPathComponent:fileSystemItem] error:nil] objectForKey:NSFileSize] unsignedIntegerValue];
        }
        
        else {
            
            result += [self folderSize:[folderPath stringByAppendingPathComponent:fileSystemItem]];
        }
    }
    
    return result;
}


#pragma mark- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return [self.contents count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static NSString* fileIdentifier = @"FileCell";
    static NSString* folderIdentifier = @"FolderCell";
    
    NSString* fileName = [self.contents objectAtIndex:indexPath.row];
    
    if ([self isDirectoryAtIndexPath:indexPath]) {
        
        NSString* path = [self.path stringByAppendingPathComponent:fileName];
        
        NSDictionary* attributesFolder = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil];
        
        AGFolderCell* cell = [tableView dequeueReusableCellWithIdentifier:folderIdentifier];
    
        cell.folderNameLabel.text = fileName;
        
        //cell.folderSizeLabel.text = [self fileSizeFromValue:[attributesFolder fileSize]];
        NSString* string = [self fileSizeFromValue:[self folderSize:path]];
        cell.folderSizeLabel.text = string;
        
        static NSDateFormatter* dateFormatter = nil;
        
        if (!dateFormatter) {
            dateFormatter = [[NSDateFormatter alloc]init];
            [dateFormatter setDateFormat:@"MM/dd/yyyy hh:mm a"];
        }
        
         cell.folderDateLabel.text = [dateFormatter stringFromDate:[attributesFolder fileModificationDate]];
        
        return cell;
        
    }else {
    
        NSString* path = [self.path stringByAppendingPathComponent:fileName];
        
        NSDictionary* attributes = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil];
        
        AGFileCell* cell = [tableView dequeueReusableCellWithIdentifier:fileIdentifier];
        
        cell.nameLabel.text = fileName;
        cell.sizeLabel.text = [self fileSizeFromValue:[attributes fileSize]];
        
        static NSDateFormatter* dateFormatter = nil;
        
        if (!dateFormatter) {
            dateFormatter = [[NSDateFormatter alloc]init];
            [dateFormatter setDateFormat:@"MM/dd/yyyy hh:mm a"];
        }
        
        cell.dateLabel.text = [dateFormatter stringFromDate:[attributes fileModificationDate]];
        
        return cell;
    }
    
    return nil;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        NSMutableArray* temp = [NSMutableArray arrayWithArray:self.contents];
        
        NSString* fileName = [temp objectAtIndex:indexPath.row];
        
        NSString* newPath = [self.path stringByAppendingPathComponent:fileName];
        
        [temp removeObject:fileName];
        
        self.contents = temp;
        
        [[NSFileManager defaultManager] removeItemAtPath:newPath error:nil];
        
        [self.tableView beginUpdates];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        
        [self.tableView endUpdates];
    }
   
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {

    return YES;

}

- (nullable NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath NS_AVAILABLE_IOS(3_0) __TVOS_PROHIBITED {
    
    return @"Remove";
}


- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath{
    
    NSString* fileName = [self.contents objectAtIndex:sourceIndexPath.row];
    NSMutableArray* tempArray = [NSMutableArray arrayWithArray:self.contents];
    
    [tempArray removeObject:fileName];
    [tempArray insertObject:fileName atIndex:destinationIndexPath.row];
    
    self.contents = tempArray;
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

#pragma mark- UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

    if ([self isDirectoryAtIndexPath:indexPath]) {
        
        return 70.f;
        
    }else {
    
        return 70.f;
    }

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if ([self isDirectoryAtIndexPath:indexPath]) {
        
        NSString* fileName = [self.contents objectAtIndex:indexPath.row];
        NSString* path = [self.path stringByAppendingPathComponent:fileName];
        
        AGDirectoryViewController* vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AGDirectoryViewController"];
        vc.path = path;
        [self.navigationController pushViewController:vc animated:YES];
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
// Override to support rearranging the table view.

@end
