//
//  ViewController.h
//  HomeWork Lesson 34 (UITableView Navigation Part 2)
//
//  Created by Anton Gorlov on 19.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

