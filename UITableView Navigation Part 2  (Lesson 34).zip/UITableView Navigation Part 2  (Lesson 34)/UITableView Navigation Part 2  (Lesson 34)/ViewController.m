//
//  ViewController.m
//  UITableView Navigation Part 2  (Lesson 34)
//
//  Created by Anton Gorlov on 13.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
