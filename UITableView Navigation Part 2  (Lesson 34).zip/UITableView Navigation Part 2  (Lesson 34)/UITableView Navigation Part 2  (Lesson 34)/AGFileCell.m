//
//  AGFileCell.m
//  UITableView Navigation Part 2  (Lesson 34)
//
//  Created by Anton Gorlov on 14.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGFileCell.h"

@implementation AGFileCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
