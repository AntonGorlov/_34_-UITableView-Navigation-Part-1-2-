//
//  AGDirectoryViewController.h
//  UITableView Navigation Part 2  (Lesson 34)
//
//  Created by Anton Gorlov on 13.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGDirectoryViewController : UITableViewController

@property (strong, nonatomic) NSString* path; // соз путь,чтобы его хранить
- (id) initWithFolderPath:(NSString*) path; //соз конструктор,который передаеь какой-то path

- (IBAction)actionInfoCell:(UIButton *)sender;


@end
