//
//  UIView+UITableViewCell.h
//  UITableView Navigation Part 2  (Lesson 34)
//
//  Created by Anton Gorlov on 18.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (UITableViewCell)

- (UITableViewCell*) superCell;


@end
