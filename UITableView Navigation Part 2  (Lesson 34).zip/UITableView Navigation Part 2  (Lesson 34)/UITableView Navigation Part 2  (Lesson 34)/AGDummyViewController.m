//
//  AGDummyViewController.m
//  UITableView Navigation Part 2  (Lesson 34)
//
//  Created by Anton Gorlov on 14.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDummyViewController.h"

@interface AGDummyViewController ()

@end

@implementation AGDummyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- Segue

- (BOOL) shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender { // перед тем как будет вызван метод "prepareForSegue" будет вызван этот метод.Будут вызваны эти Segue "YES" or "NO"
    
    NSLog(@"shouldPerformSegueWithIdentifier :%@", identifier);
    
    return YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(nullable id)sender NS_AVAILABLE_IOS(5_0) { //сюда приходит Segue,когда мы хотим запустить одну из каких-то связей (существляем переход).Каждй раз,когда реализ. кнопка с Segue,то она будет заходить в этот метод
    
    NSLog(@"prepareForSegue : %@",segue.identifier);
    
    //segue.destinationViewController //если нужно что-то передавать
}


@end
