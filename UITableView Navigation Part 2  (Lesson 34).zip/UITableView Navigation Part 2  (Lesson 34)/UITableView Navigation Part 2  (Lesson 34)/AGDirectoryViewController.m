//
//  AGDirectoryViewController.m
//  UITableView Navigation Part 2  (Lesson 34)
//
//  Created by Anton Gorlov on 13.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDirectoryViewController.h"
#import "AGFileCell.h"
#import "UIView+UITableViewCell.h" // категория идет с "+"

@interface AGDirectoryViewController ()


@property (strong, nonatomic) NSArray* contents; //соз массив,чтобы мы могли не переживать,что содержимое папки измениться и таблица перестанет работать (contents - имена файлов и директорий)
@property (strong,nonatomic) NSString* selectedPath;

@end

@implementation AGDirectoryViewController

/*
+ (instancetype)alertControllerWithTitle:(NSString *)title
                                 message:(NSString *)message
                          preferredStyle:(UIAlertControllerStyle)preferredStyle
{
    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction* action = [UIAlertAction actionWithTitle:@"OK"
                                                     style:UIAlertActionStyleDestructive
                                                   handler:^(UIAlertAction *action) {}];
    [alert addAction:action];
    
    
    return  [self alertControllerWithTitle:@"dgrgse" message:@"dhhtrth" preferredStyle:UIAlertControllerStyleActionSheet];
    
}
*/

- (id) initWithFolderPath:(NSString *) path {
    
    self = [super initWithStyle:UITableViewStylePlain];
    
    if (self) {
        
        self.path = path;
        
    }
    
    return self;
}

- (void) setPath:(NSString *)path { //устанавливаем сеттер для path (cм урок 4 Part 1)
    
    _path = path; //внутр-я переменная

    NSError* error = nil; //соз error (ошибки нет)если будет,то появиться
    
    self.contents = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.path //передаем путь
                                                                        error:&error]; //заполняем массив (contents) строками это названи файлов или директорий кот у нас лежат.
    
    if (error) { //если ошибка,то
        
        NSLog(@"%@",[error localizedDescription]); //он обвернет ее так как передаем указатель,он заполнит своей ошибкой
        
    }//localizedDescription - вывидет какое-то локализированное сообщение

    [self.tableView reloadData]; //перезагрузим таблицу
    
    self.navigationItem.title = [self.path lastPathComponent]; //покажем последний компонент в шапке (где находимся) бла/блабла/бла2, бла2-последний компонент,где находимся
}

- (void)viewDidLoad { //если viewDidLoad загрузился
    
    [super viewDidLoad];
    
    
    if (!self.path) { //если наша path не установилась
        
        self.path = @"/Users/AntonGorlov/Documents/Антон/Антошкины ДокументЫ/IOS Developer/Functiontest/PropertiesTest2"; //делаем нашу path равной этой штуке и стартанет наш VC с этого пути. (так мы защитили себя от "nil" в таблице)
   
    }
      }

- (void) viewWillAppear:(BOOL)animated { // соз метод ,так как пропала кнопка "Root"
    [super viewWillAppear:animated];
 
    //при нажатии на кнопку переходит на главный ViewController
    
    if ([self.navigationController.viewControllers count] > 1) { //если Controller не находится на 1-м стеке ,то ...
        UIBarButtonItem* item = [[UIBarButtonItem alloc] initWithTitle:@"Back to Root" style:UIBarButtonItemStylePlain
                                                                target:self
                                                                action:@selector(actionBackToRoot:)]; //уничтожает все viewControllers и возвращается на главный viewController
        
        self.navigationItem.rightBarButtonItem = item;
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.contents count]; //выводим массив наших contents (кол-во содерж файлов и папок)
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* fileIdentifier = @"FileCell";
    static NSString* folderIdentifier = @"FolderCell";
    
     NSString* fileName = [self.contents objectAtIndex:indexPath.row]; //соз строки на основе массива обьктов по индексу
    
    
    if ([self isDirectoryAtIndexPath:indexPath]) {
        
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:folderIdentifier]; // метод пытаеться взять ячейку с identifier (ее там нет,нужно создать)
        cell.textLabel.text = fileName; //выставляем в text все наши имена и папки в директории
        
        return cell;

    }else { //если file,то показываем file
    
        NSString* path = [self.path stringByAppendingPathComponent:fileName]; //вернет строку содержащию наш новый path
        NSDictionary* attributes = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil]; //берем атрибуты у file
        
       AGFileCell* cell = [tableView dequeueReusableCellWithIdentifier:fileIdentifier]; //берем уже наш новый класс (новую ячейку)
        
        cell.nameLabel.text = fileName;
        //cell.sizeLabel.text = [self] // у Dictionarу атрибутов есть метод "file size" - переопределенный через категорию NSFileAttributes
        cell.sizeLabel.text = [self fileSizeFromValue:[attributes fileSize]];
        
        static NSDateFormatter* dateFormatter = nil; //исп static так как хотим испльзовать для всех (static мы не можем инициализировать alloc and init, делаем "!"  если его нет)
        
        if (!dateFormatter) { //если его нет
            
            dateFormatter = [[NSDateFormatter alloc]init]; //инициализируем
            [dateFormatter setDateFormat:@"MM/dd/yyyy hh:mm a"]; // "a" - am
        }
        
        cell.dateLabel.text = [dateFormatter stringFromDate:[attributes fileModificationDate]]; //переопределен через категорию NSFileAttributes
        
        return cell;
    }
    
    return nil;
    
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath { // метод,который переопределяет высоту ячейки

    if ([self isDirectoryAtIndexPath:indexPath]) { // если директория
        
        return 44.f;
        
    }else {//если нет
        
        return 70.f;
    }

}


// При нажатии на папку идем дальше (на файл - ничего)

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath { //когда нажали
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES]; //чтобы не был выбранным
    
    if ([self isDirectoryAtIndexPath:indexPath]) { //проверяем директория это или нет
        
        NSString* fileName = [self.contents objectAtIndex:indexPath.row];
        
        NSString* path = [self.path stringByAppendingPathComponent:fileName]; // инициализируем path
        
       /* // Загружаем из кода
        AGDirectoryViewController* vc = [[AGDirectoryViewController alloc] initWithFolderPath:path]; //соз в нашем  Controller обьекта класса AGDirVC точно такой же обьяект такого класса (но он не заработает ,пока не поставим в стек)
        
        [self.navigationController pushViewController:vc animated:YES]; // добавляем на стек наших контроллеры на navigationController
       */
        
        //Загружаем из storyBoard
        /*
        AGDirectoryViewController* vc = [self. storyboard instantiateViewControllerWithIdentifier:@"AGDirectoryViewController"]; //identifier берем в storyBoard
        vc.path = path; //устанавливаем path
        [self.navigationController pushViewController:vc animated:YES]; // отправляем на navigation стек
         */
        
        /*
        //загружаем из storyboard
        AGDirectoryViewController* vc = [self. storyboard instantiateViewControllerWithIdentifier:@"AGDirectoryViewController"]; //identifier берем в storyBoard
        vc.path = path; //устанавливаем path
        [self.navigationController pushViewController:vc animated:YES]; // отправляем на navigation стек
        */
        
        self.selectedPath = path; // selectedPath будет равен новому пути (взяли новый путь)
        [self performSegueWithIdentifier:@"navigateDeep" sender:nil]; // вызываем Segue без кнопок (из кода)
    }
    
}

#pragma mark - Methods

//определим папка это или файл
- (BOOL) isDirectoryAtIndexPath:(NSIndexPath*) indexPath {
    
    NSString* fileName = [self.contents objectAtIndex:indexPath.row]; //берем fileName из contents по indexPath (это последний contents,он не вкл весь path)
    
    NSString* filePath = [self.path stringByAppendingPathComponent:fileName]; //добавляем строку в путь компоненты (берем self.path,узнаем его contents,сколько файлов стоити прсото к нашему пути добавляем название этого файла или папки)
    
    BOOL isDirectory = NO; //узнаем директория это или нет.(по умолчанию NO)
    
    [[NSFileManager defaultManager] fileExistsAtPath:filePath isDirectory:&isDirectory]; //спрашиваем существует ли файл по такому пути с возвратом BOOL и является он директорией. Если является,то поменяет на "YES"
    
    return isDirectory;
}

- (void) dealloc {
    
    NSLog(@"controller with path %@ has been deallocated",self.path);
    
}
- (void) viewDidAppear:(BOOL)animated { // когда view появилась на экране
    
    [super viewDidAppear:animated];
    
    NSLog(@"path = %@",self.path); //путь
    NSLog(@"view controllers on stack = %lu",[self.navigationController.viewControllers count]); //кол-во контроллеров на стеке
    NSLog(@"index on stack %lu",[self.navigationController.viewControllers indexOfObject:self]); //узнаем индек нашего контроллера
}

#pragma mark -Action

- (void) actionBackToRoot:(UIBarButtonItem*) sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}


//стрелки в storyboard
#pragma mark- Segue

- (BOOL) shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender { // перед тем как будет вызван метод "prepareForSegue" будет вызван этот метод.Будут вызваны эти Segue "YES" or "NO"

    NSLog(@"shouldPerformSegueWithIdentifier :%@", identifier);
    
    return YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(nullable id)sender NS_AVAILABLE_IOS(5_0) { //сюда приходит Segue,когда мы хотим запустить одну из каких-то связей (существляем переход).Каждй раз,когда реализ. кнопка с Segue,то она будет заходить в этот метод

    NSLog(@"prepareForSegue : %@",segue.identifier);
    
    AGDirectoryViewController* vc = segue.destinationViewController; //куда переходим
    vc.path = self.selectedPath; // чему равен пас (Не нужно делать "Push" ,так как это показывается во время "Push",когда 2-й VC  уже создан и "Push" проходит без нас)
}



- (IBAction)actionInfoCell:(UIButton *)sender {
    
    NSLog(@"actionInfoCell");
    
    UITableViewCell* cell = [sender superCell]; // появился метод
    
    if (cell) {
        
        NSIndexPath* indexPath = [self.tableView indexPathForCell:cell]; // у нашей tableView есть метод "indexPathForCell" - на какой indexPath мы нажали,даже ,если ячейки перетусованы
        
     
       
     
        UIAlertController* alertView = [UIAlertController alertControllerWithTitle:@"Info"
                                                                           message:[NSString stringWithFormat:@"action %ld %ld",indexPath.section , indexPath.row]
                                                                        preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}];
       
        [alertView addAction:defaultAction];
        
        [self presentViewController:alertView
                           animated:YES
                         completion:nil];
      
    }
    
 
    
    
    
}


- (NSString*) fileSizeFromValue: (unsigned long long) size { //Размеры файлов unsigned - безнаковое число
    
    static NSString* units []= {@"B", @"KB",@"MB", @"GB",@"TB"}; //static - не изменяемый
    static int unitCount = 5; // кол-во
    
    int index = 0;
    
    double filesize = (double)size; //приводим нашу size k double, чтобы можно было ее делить
    
    while (filesize > 1024 && index < unitCount) {
        filesize /= 1024;
        index ++;
    }

    return [NSString stringWithFormat:@"%.2f %@",filesize,units[index]];
}

@end
