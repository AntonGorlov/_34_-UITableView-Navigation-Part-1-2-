//
//  UIView+UITableViewCell.m
//  UITableView Navigation Part 2  (Lesson 34)
//
//  Created by Anton Gorlov on 18.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "UIView+UITableViewCell.h"

@implementation UIView (UITableViewCell)
//Как "Custom" кнопке сказать,что по какому Index нажата кнопка
- (UITableViewCell*) superCell {

    if (!self.superview) { // если ее нет,дошли до UIWindow,то возвращаем "Nil",нет superCell
        return nil;
    }
    if ([self.superview isKindOfClass:[UITableViewCell class]]) { //если он является ячейкой ее "superView" ("superView" этой кнопки)
        return (UITableViewCell*)self.superview; //то возвращаем его "superview", кот является ячейкой.Если кнопка лежит прямо на ячейки,то возвращаем
    }
    return [self.superview superCell]; //если не ячейка,тогда
}



@end
