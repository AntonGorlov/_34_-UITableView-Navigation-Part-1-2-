//
//  AGFolder.h
//  HomeWork Lesson 33 (UItableView Navigation Part 1)
//
//  Created by Anton Gorlov on 08.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGFolder : NSObject

@property (strong, nonatomic) NSArray* folders;
@end
