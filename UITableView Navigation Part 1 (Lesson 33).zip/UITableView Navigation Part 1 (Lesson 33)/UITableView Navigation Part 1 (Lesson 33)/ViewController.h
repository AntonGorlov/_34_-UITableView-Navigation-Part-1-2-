//
//  ViewController.h
//  UITableView Navigation Part 1 (Lesson 33)
//
//  Created by Anton Gorlov on 05.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

